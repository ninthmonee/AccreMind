AccreMind 图标素材包

设计：层积 A。三个几何层共同组成 A，表达研发经验逐步沉淀为知识资产。

accremind-icon.svg：应用图标矢量源文件。
accremind-icon-*.png：16、24、32、64、128、256、512、1024 像素图标。
accremind-mark.svg / .png：透明背景深青单色符号。
accremind-preview.png：明暗背景和尺寸预览。

小尺寸 16、24 像素符号使用纯薄荷青；其他尺寸使用连续薄荷渐变。
单色深青为 #006766；在深色背景可改为 #70E6E3 或白色。
保持比例和留白。
